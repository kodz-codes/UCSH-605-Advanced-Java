package com.example.demo;

import org.springframework.web.bind.annotation.*;
import java.util.*;
import com.mycompany.app.*;
import java.lang.*;

@RestController
public class DemoController{

		@GetMapping("/home")
		public String first(){
			return"Siaram";
		}
		
		@PostMapping("/palindrome")
		public String palindrome_check(@RequestBody Map<String,String> input){
			String send = input.get("input");
			Palindrome obj = new Palindrome();
			String output = obj.longestSubstr(send);
			return output;
		}
		
		@PostMapping("/word")
		public String word_converter(@RequestBody Map<String,String> data){
			String send1 = data.get("data");
			//String send2 = options.get("options");
			WordConverter obj = new WordConverter();
			//String ouput = obj.convert_to_ascii(send1, send2);
			String output = obj.convert_to_ascii(send1);
			return output;
		}
}
