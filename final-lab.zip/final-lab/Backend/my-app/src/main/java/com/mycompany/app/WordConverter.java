package com.mycompany.app;

import java.io.*;
import java.util.*;

public class WordConverter{
	public String convert_to_ascii(String str){
		int length = str.length(), i = 0 ;
		String output = "";
		for(i = 0; i < str.length(); i++){
			 char arr = str.charAt(i);
			 int number = (int)(arr);		 
			 output = output + number;
			 output = output + " ";
		}
		return output;
	}
	
	public static void main(String... args){
		String word = "adaagdha";
		String ans = "";
		WordConverter obj = new WordConverter();

		ans = obj.convert_to_ascii(word);
		System.out.println(ans);
	}
}
